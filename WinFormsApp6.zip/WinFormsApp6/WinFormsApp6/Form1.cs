using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DailyTemps
{
    public partial class Form1 : Form
    {
        private List<int> temperatures = new List<int>();
        private int enteredTemperatures = 0;
        private int totalTemperature = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtTemperature.Text, out int temperature))
            {
                if (temperature >= -20 && temperature <= 130)
                {
                    temperatures.Add(temperature);
                    totalTemperature += temperature;
                    enteredTemperatures++;

                    if (enteredTemperatures == 7)
                    {
                        btnEnter.Enabled = false;
                        DisplayTemperatures();
                    }
                }
                else
                {
                    MessageBox.Show("Temperature must be between -20 and 130 Fahrenheit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid temperature.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DisplayTemperatures()
        {
            string temperaturesText = "Temperatures entered: ";
            foreach (int temp in temperatures)
            {
                temperaturesText += temp + "�F, ";
            }

            temperaturesText = temperaturesText.Remove(temperaturesText.Length - 2); // Remove the last comma and space
            temperaturesText += "\nAverage temperature: " + (totalTemperature / 7) + "�F";

            MessageBox.Show(temperaturesText, "Temperatures", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
